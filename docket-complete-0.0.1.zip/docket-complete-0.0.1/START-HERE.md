# START HERE - Docket 0.0.1

Docket takes a ticket and runs it through a 9-gate AI pipeline
(comprehension -> context -> plan -> test-spec -> develop -> review ->
security -> QA -> mutation), recording every step to an append-only
ledger with a read-only dashboard. Models come from GitHub Copilot
through VS Code - no API keys, no Docker, no Node needed to USE it.

Every step below is a manual step in the VS Code UI. This package
never asks you to execute a supplied script, and installation needs
no terminal.

## Set up (one time)

1. Open VS Code.
2. Open the Extensions view (the squares icon in the Activity Bar).
3. Open the "..." menu at the top of the Extensions view and select
   "Install from VSIX...".
4. Select docket-0.0.1.vsix (in the complete package it sits right
   beside this file).
5. Extract or open the workbench: keep OPEN-DOCKET.code-workspace,
   START-HERE.md and the docket/ folder together in one folder.
6. Copy or clone a Git project BESIDE docket/ (inside this folder).
   Layout rule: your project is a sibling of docket/, never inside it,
   and it must contain a .git directory.
7. Copy docket/tickets/_template.md to a real filename such as
   docket/tickets/DEMO-1.md and fill it in. The template itself is
   IGNORED: ticket files whose names start with an underscore never
   appear in the ticket list, so Docket has no ticket to run until
   you make that copy.
8. Open OPEN-DOCKET.code-workspace (double-click it, or File -> Open
   Workspace from File...).
9. From the Command Palette run, in order:
   - "Docket: Run Preflight Probe"   (checks your environment)
   - "Docket: Select Project"        (picks the sibling repository)
   - "Docket: Run Ticket From File (no Jira)"

## Before the first run

- Trust: Docket runs your project's code and tests through your own
  Python environment. Only work on repositories you trust, and only
  accept VS Code's workspace-trust prompt for folders you trust.
- Sign into GitHub Copilot in VS Code (Docket's models come from
  Copilot via vscode.lm; without it no pipeline stage can run).
- Python 3.10+ must be installed, and your project needs its venv and
  test dependencies (pytest + coverage).

## Good to know

- Opening this folder cannot silently install anything: an unpublished
  extension only enters VS Code through the explicit "Install from
  VSIX" step above. That one manual UI step is the whole install.
- To see what is running: Command Palette ->
  "Developer: Show Running Extensions" lists every active extension,
  including Docket, with its activation cost.
- Jira is optional. If you use it, credentials belong in environment
  variables (JIRA_BASE_URL, JIRA_PAT) or in the gitignored
  docket/.local/docket-runtime.env (copy the .example file beside it).
  Never put credentials in config.json - it only ever holds the NAMES
  of environment variables.

## Offline alternative: the extension-folder ZIP

The VSIX is the recommended install - VS Code validates and manages
that format. If "Install from VSIX" is not possible in your setup,
docket-extension-folder-0.0.1.zip is a place-only alternative:
extract it into your VS Code extensions directory -

    macOS/Linux:  ~/.vscode/extensions/
    Windows:      %USERPROFILE%\.vscode\extensions\

so that the result is the directory
~/.vscode/extensions/docket.docket-0.0.1/ - then restart VS Code
or run "Developer: Reload Window".

More documentation: docket/README.md (quickstart) and
docket/HEADLESS.md (optional terminal-only mode for development
machines with the claude CLI; VS Code + Copilot is the normal path).
